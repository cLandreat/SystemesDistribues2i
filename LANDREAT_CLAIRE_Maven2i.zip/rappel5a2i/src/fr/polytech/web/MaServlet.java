package fr.polytech.web;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fr.polytech.systemes.SommeProduit;




@WebServlet("/MaServlet")
public class MaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	//SommeProduitTest SommeProduit = new SommeProduit();
	SommeProduitTest = new SommeProduitTest();
	
	
    public MaServlet() {
        super();

    }
    
    public double Somme(double nombre1,double nombre2) {
    	double total = 0;
    	total = nombre1 + nombre2;
    	return total;
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String nombre1 = request.getParameter("nombre1"); 
		//request.setAttribute("nombre1", nombre1);
		
		//String nombre2 = request.getParameter("nombre2"); 
		//request.setAttribute("nombre2", nombre2);
		
		//int nb1=Integer.parseInt(nombre1);
		//int nb2=Integer.parseInt(nombre2);
		
		
		//PrintWriter printwriter = response.getWriter();
		
		HttpSession session=request.getSession();
		
		Integer nombre1= Integer.parseInt(request.getParameter("nombre1"));
		//printwriter.println("Nombre1: "+nombre1);
		Integer nombre2= Integer.parseInt(request.getParameter("nombre2"));
		//printwriter.println("Nombre2: "+nombre2);
		
		session.setAttribute("nombre1", nombre1);
        session.setAttribute("nombre2", nombre2);
		
		
		
		
		Integer totalsomme = nombre1 + nombre2;
		//printwriter.println("SOMME: "+totalsomme);
		
		Integer totalmulti = nombre1 * nombre2;
		
		session.setAttribute("totalmulti", totalmulti);
        session.setAttribute("totalsomme", totalsomme);
		
		//printwriter.println("Multiplication: "+totalmulti);
		
		
		
		/*double nombre1;
		double nombre2;
		
		try {
			nombre1 = Double.parseDouble(request.getParameter("nombre1"));
			nombre2 = Double.parseDouble(request.getParameter("nombre2"));
			
			Somme(nombre1, nombre2);
			
			
		}catch(NumberFormatException ex) {
			nombre1=0;
			nombre2=0;
		}*/
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/LaVue.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doGet(request, response);
	}

}
