package fr.i.cm12octobre.web.controller.web;


import java.util.List;


public interface ProductDao {

    public List<Product> findAll();
    public Product findbyId(int code);
    public Product save(Product product);
}
